import React from "react";
import "./style.scss";

const Index = () => {
  return (
    <div className="text-center">
      <h1>404 page not found</h1>
    </div>
  );
};

export default Index;
