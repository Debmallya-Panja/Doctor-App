import React from "react";

const Index = () => {
  return (
    <div>
      <h1>Dashboard</h1>
    </div>
  );
};

export default Index;
