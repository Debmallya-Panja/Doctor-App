import React from "react";
import "./style.scss";

const Index = () => {
  return (
    <div className="admin-loading">
      <div className="flex-center flex-column">
        <div className="loader"></div>
      </div>
    </div>
  );
};

export default Index;
