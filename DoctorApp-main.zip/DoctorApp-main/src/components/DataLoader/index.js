import React from "react";
import "./style.scss";

const Index = () => {
  return (
    <div className="data-loader-container">
      <div className="flex-center flex-container">
        <div className="loader"></div>
      </div>
    </div>
  );
};

export default Index;
